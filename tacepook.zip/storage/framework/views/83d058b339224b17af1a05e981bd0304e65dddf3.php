<?php $__env->startSection('content'); ?>
<style type="text/css">
    .navbar-light .navbar-brand{
        color: #872166;
        font-weight: 800;
        font-size: 30px;
        padding: 0;
    }
    div#collapsibleNavbar{
        margin-top: 0;
    }
    header .header-wrapper{
        box-shadow: 0 5px 10px 0 rgba(79,36,85,.15)
    }
    .navbar-light .navbar-nav .nav-link{
        color: #872166;
        font-weight: 600;
    }
.form-group{
      position: relative;
    }
    .form-group ion-icon{
      position: absolute;
      bottom: 0;
      padding: 8px;
      right: 0;
      cursor: pointer;
    }
</style>
<section>
<div class="container p-5">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-5 loginform">
            <h5 class="loginstyle signup-style">Login to <?php echo e(env('APP_NAME')); ?></h5>
            <form id="pop-login-form" action="<?php echo e(route('login')); ?>" method="post">
               <?php echo csrf_field(); ?>
                <input type="hidden" id="pop_signin_came_from" name="came_from" value="">
                <fieldset class="form-group loginstyle">
                    <div class="form-group">
                        <label class="control-label" for="pop-login-username" aria-required="true" name="Email">
                        Email
                        </label>
                        <input type="email" id="pop-login-username" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="help-block"></p>
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="pop-login-password" required>Password</label>
                        <input type="password" id="pop-login-password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" aria-required="true" aria-describedby="userPassword-error" aria-invalid="true" required="">
                        <ion-icon name="eye-off" class="show-password"></ion-icon>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="help-block"></p>
                    </div>
                </fieldset>
                <div class="checkbox loginstyle">
                    <div class="form-group">
                        <div class="checkbox">
                            <label for="pop-login-rememberme">
                                
                            <input type="checkbox" id="remember" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            Remember Me
                            </label>
                        </div>
                    </div>
                </div>
                <p id="pop-form-msg" class="help-block"></p>
                <button type="submit" class="btn btn-primary log-button theme-green" id="pop-login-button">Login</button>
                <span class="btn btn-primary log-button" id="pop-login-button-loading" style="display:none;">Authenticating..</span>
            </form>
        </div>
        <div class="col-md-5 login-p2">
            <h5 class="loginstyle">Don't have an account?</h5>
            <button class="btn theme-green signup-link" onclick="window.location.href = '<?php echo e(route('register')); ?>'">Sign Up</button>
            <br><br>
            <h5 class="loginstyle">Forgot your Password?</h5>
            <a class="btn btn-grey" href="<?php echo e(route('password.request')); ?>">Reset</a>
            <br><br><br>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lottery\resources\views/auth/login.blade.php ENDPATH**/ ?>