<!doctype html>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slick.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slick-theme.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
        <link href="<?php echo e(asset('css/toastr.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">  
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.min.css">      
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">      
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css">      
    </head>
    <body>
<main>
<script>
    var base_url = "<?php echo e(url('/')); ?>";
</script>
<header>
    <nav class="navbar navbar-expand-md navbar-light p-0">
        <div class="container-fluid header_inner py-2 header-wrapper">
            <!-- Brand -->
            
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(env('APP_NAME')); ?>

            </a>
            <!-- Toggler/collapsibe Button -->
            <div class="button_wrap align-items-center justify-content-between mobile-inputs">
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar" aria-expanded="true">
                <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('lottery.index')); ?>">Live Lottery</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('winner.index')); ?>">Winners Club</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('donate.index')); ?>">Donations</a>
                    </li>

                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('cart')); ?>">Cart(<?php echo e(\Cart::getContent()->count()); ?>)</a>
                    </li>
                    <li class="nav-item d-block d-sm-none d-none d-sm-block d-md-none">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Sign Up</a>
                    </li>
                    <li class="nav-item d-block d-sm-none d-none d-sm-block d-md-none">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Sign In</a>
                    </li>  

                    <?php else: ?>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('profile')); ?>">My Profile</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('change-password')); ?>">Change Password</a>
                      </li>  
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('cart')); ?>">Cart(<?php echo e(\Cart::getContent()->count()); ?>)</a>
                      </li>                    
                      <li class="nav-item d-block d-sm-none d-none d-sm-block d-md-none">
                        <a class="nav-link" onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">Sign Out</a>
                    </li>                                  
                    <?php endif; ?>
                    
                </ul>
                <?php if(auth()->guard()->guest()): ?>
                <div class="button_wrap ">
                    <?php if(Route::has('register')): ?>
                    <div class="left ">
                        <button class="d-none d-sm-block d-sm-none d-md-block">
                        <a href="<?php echo e(route('register')); ?>" class="">Sign Up</a>
                        </button>
                    </div>
                    <?php endif; ?>
                    <div class="right">
                        <button onclick="location.href = 'login.php';" style="cursor: pointer;" class="d-none d-sm-block d-sm-none d-md-block">
                        <a href="<?php echo e(route('login')); ?>">Sign In</a>
                        </button>
                    </div>
                </div>
                <?php else: ?>
                <div class="button_wrap">
                    <div class="left">
                        <button class="d-none d-sm-block d-sm-none d-md-block">
                        <a href="<?php echo e(route('register')); ?>" onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">Sign Out</a>
                        </button>
                    </div>                    
                </div>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header>  
    <?php echo $__env->yieldContent('content'); ?>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4 last-on-small-screen">
                <div class="inner-footer">
                    <a href="<?php echo e(url('/')); ?>">
                    <?php echo e(env('APP_NAME')); ?>

                    </a>
                </div>
                <div class="add-footer">
                        <p>3650 abc streat India, IN 100001</p>
                        <p>Phone: 763-000-0000</p>
                    </div>
            </div>
            <div class="col-md-4">
                <div class="inner-footer">
                    <div class="title-foot mb-3">
                        <h4 style="font-size: 26px;font-weight: 700;">Quick Links</h4>
                    </div>
                    <div class="menu-footer">
                        <ul class="pl-0 list-unstyled">
                            
                            <li class="mb-3">
                                <a href="<?php echo e(url('/about-us')); ?>">About Us</a>
                            </li>
                            
                            <li class="mb-0">
                                <a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="inner-footer">
                    <div class="title-foot mb-3">
                        <h4 style="font-size: 26px;font-weight: 700;">Quick Links</h4>
                    </div>
                    <div class="menu-footer">
                        <ul class="pl-0 list-unstyled">
                            
                            <li class="mb-3">
                                <a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a>
                            </li>
                            
                            <li class="mb-0">
                                <a href="<?php echo e(url('/term-condition')); ?>">Terms and Conditions</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<style type="text/css">
    .primary-logo-color > a{
        color: #872266;
    }
    .primary-logo-color > a:hover{
        color: #212121;
    }
</style>
<div class="copyright py-4">
    <div class="container">
        <div class="row align-items-center" style="opacity: 0.85">
            <div class="col-sm-3 text-sm-left primary-logo-color"><a href="http://www.eraise.in" class="color-white ">
                A Boss Product</a></div>
            <div class="col-sm-6 mt-3 mt-sm-0">
                <p class="color-white lh-6 mb-0 fw-600" style="text-align: center;">© 2020 Lottery Hills.</p>
            </div>
            <div class="col text-sm-right mt-3 mt-sm-0 primary-logo-color"><a class="color-white" href="http://www.anitco.in" target="_blank">Developed by ANITCO</a></div>
        </div>
    </div>
</div>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/toastr.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('js/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
</body>
</html>

<script type="text/javascript">
$(document).ready(function(){
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:0,
        responsiveClass:true,
        autoplay:true,
        responsive:{
            0:{
                items:1,
                nav:true
            }
        }
    })
});
</script>


<?php if(session()->has('message')): ?>
<script>
$(document).ready(function () {
    setTimeout(function () {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            showMethod: 'slideDown',
            timeOut: 4000,
        }
        ;
                toastr.success('<?php echo e(session()->get('message')); ?>', 'Success');
    }, 300);
});
</script>
<?php endif; ?>
<?php if(session()->has('error_message')): ?>
<script>
    $(document).ready(function () {
        setTimeout(function () {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 4000
            }
            ;
                    toastr.error('<?php echo e(session()->get('error_message')); ?>', 'Error');
        }, 300);
    });
</script>
<?php endif; ?>


<script type="text/javascript">
    $(function(){
  
      $('.show-password').click(function(){
           
            if($(this).attr('name') == 'eye-off'){
               
              $(this).attr('name','eye');
              
              $(this).prev().attr('type','text');
                
            }else{
             
              $(this).attr('name','eye-off');
              
              $(this).prev().attr('type','password');
            }
        });
});
</script>
<?php /**PATH E:\xampp\htdocs\lottery\resources\views/layouts/app.blade.php ENDPATH**/ ?>